cartoframes package
===================

Subpackages
-----------

.. toctree::

    cartoframes.contrib

Submodules
----------

.. toctree::

   cartoframes.analysis
   cartoframes.batch
   cartoframes.context
   cartoframes.credentials
   cartoframes.dataobs
   cartoframes.examples
   cartoframes.layer
   cartoframes.maps
   cartoframes.styling
   cartoframes.utils

Module contents
---------------

.. automodule:: cartoframes
    :members:
    :undoc-members:
    :show-inheritance:
