"""cartoframes version number"""
__title__ = 'cartoframes'
__description__ = 'CARTO Python package for data scientists'
__version__ = '0.7.2'
__url__ = 'https://github.com/CartoDB/cartoframes'
__author__ = 'Andy Eschbacher'
__email__ = 'andy@carto.com'
__license__ = 'BSD'
